import discord
from discord import app_commands
from discord.ext import commands
from utils.storage import load_movies, save_movies
from utils.imdb import fetch_movie_data

class AddMovieCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="addmovie", description="Add a movie to your watchlist.")
    @app_commands.describe(
        title="The title of the movie you want to add.",
        imdb_id="The IMDb ID of the movie (optional).",
        year="The release year of the movie (optional).",
        filepath="The path to the movie file (optional).",
        genre="The genre of the movie (optional)."
    )
    async def add_movie(
        self,
        interaction: discord.Interaction,
        title: str,
        imdb_id: str = None,
        year: str = None,
        filepath: str = None,
        genre: str = None
    ):
        try:
            movie_data = fetch_movie_data(imdb_id=imdb_id, title=title)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error fetching movie data: {e}", ephemeral=True)
            return

        # Allow manual overrides if provided
        if year:
            movie_data["year"] = year
        if genre:
            movie_data["genre"] = genre
        movie_data["filepath"] = filepath if filepath else None

        # Check for duplicates by imdb_id
        movies = load_movies()
        if any(m.get("imdb_id") == movie_data.get("imdb_id") for m in movies):
            await interaction.response.send_message("⚠️ This movie is already in your watchlist.", ephemeral=True)
            return

        # Save and respond
        movies.append(movie_data)
        save_movies(movies)

        embed = discord.Embed(
            title=f"{movie_data['title']} ({movie_data['year']})",
            description=movie_data.get("plot", "No description available."),
            color=discord.Color.teal()
        )
        embed.add_field(name="Genre", value=movie_data.get("genre", "N/A"), inline=True)
        embed.add_field(name="IMDb", value=movie_data["imdb_url"], inline=False)
        if filepath:
            embed.add_field(name="File Path", value=filepath, inline=False)
        if movie_data.get("poster") and movie_data["poster"] != "N/A":
            embed.set_thumbnail(url=movie_data["poster"])

        await interaction.response.send_message(embed=embed)
        await interaction.followup.send("✅ Movie added to your watchlist!", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(AddMovieCog(bot))